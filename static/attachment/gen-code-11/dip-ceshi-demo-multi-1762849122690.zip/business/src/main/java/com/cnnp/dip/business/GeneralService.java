package com.cnnp.dip.business;

/**
 * 自动生成的业务服务占位类: General
 * 请在此处编写具体业务逻辑。
 */
public class GeneralService {
}
