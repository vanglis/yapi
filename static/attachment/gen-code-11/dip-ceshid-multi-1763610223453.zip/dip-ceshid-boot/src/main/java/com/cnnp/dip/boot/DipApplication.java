package com.cnnp.dip.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 多模块启动入口 (boot 模块)。
 * 组件扫描根包: com.cnnp.dip
 */
@SpringBootApplication(scanBasePackages = "com.cnnp.dip")
public class DipApplication {
    public static void main(String[] args) {
        SpringApplication.run(DipApplication.class, args);
    }
}
