

# PostApiGetBasicResourcesRequest


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**codeTypeList** | **List&lt;String&gt;** | 值列表类型 |  [optional] |
|**year** | **BigDecimal** | 年份 |  |
|**resourcesType** | **String** | 资源类型；staticCode、filterOption |  |
|**expertId** | **String** | 专家id |  [optional] |



