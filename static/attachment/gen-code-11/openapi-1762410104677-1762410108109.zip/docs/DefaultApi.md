# DefaultApi

All URIs are relative to *http://localhost*

| Method | HTTP request | Description |
|------------- | ------------- | -------------|
| [**apiGetBasicResourcesPost**](DefaultApi.md#apiGetBasicResourcesPost) | **POST** /api/getBasicResources | 任务管理下拉框+事实问题下拉框+专家列表 |
| [**apiGetBasicUserInfoPost**](DefaultApi.md#apiGetBasicUserInfoPost) | **POST** /api/getBasicUserInfo | 用户信息接口 |
| [**apiGetCurrentTimestampPost**](DefaultApi.md#apiGetCurrentTimestampPost) | **POST** /api/getCurrentTimestamp | 获取当前的时间戳 |
| [**apiGetInspectorsListPost**](DefaultApi.md#apiGetInspectorsListPost) | **POST** /api/getInspectorsList | 根据年份、电厂和领域获取专家列表 |


<a id="apiGetBasicResourcesPost"></a>
# **apiGetBasicResourcesPost**
> Object apiGetBasicResourcesPost(contentType, postApiGetBasicResourcesRequest)

任务管理下拉框+事实问题下拉框+专家列表

输入样例：  &#x60;&#x60;&#x60; 1、查询值列表（注：获取全部的电厂、专家时，无需传codeType，其他的都需要传codeType，具体codeType请参考[http://conf.cnnp.com.cn/pages/viewpage.action?pageId&#x3D;44437728](http://conf.cnnp.com.cn/pages/viewpage.action?pageId&#x3D;44437728)）  {   \&quot;codeTypeList\&quot;: [     \&quot;inspect_method\&quot;,     \&quot;fact_category\&quot;   ],  \&quot;resourcesType\&quot;: \&quot;staticCode\&quot; }  2、查询筛选下拉框  {   \&quot;year\&quot;: 2025,   \&quot;expertId\&quot;: \&quot;t_zhongkai1\&quot;,   \&quot;resourcesType\&quot;: \&quot;filterOption\&quot; } &#x60;&#x60;&#x60;  输出样例  &#x60;&#x60;&#x60; 1、查询值列表   {   \&quot;getStaticCodeListVo\&quot;: {     \&quot;inspectorList\&quot;: [       {         \&quot;certCode\&quot;: \&quot;360782199303150037\&quot;,         \&quot;email\&quot;: \&quot;t_zhongkai@cnnp.com.cn\&quot;,         \&quot;phone\&quot;: \&quot;18575503315\&quot;,         \&quot;sex\&quot;: \&quot;1\&quot;,         \&quot;userCode\&quot;: \&quot;80283102\&quot;,         \&quot;userName\&quot;: \&quot;钟锴\&quot;       },      {         \&quot;certCode\&quot;: \&quot;140203199703080433\&quot;,         \&quot;email\&quot;: \&quot;t_liangyue01@cnnp.com.cn\&quot;,         \&quot;phone\&quot;: \&quot;13641927040\&quot;,         \&quot;sex\&quot;: \&quot;1\&quot;,         \&quot;userCode\&quot;: \&quot;80294867\&quot;,         \&quot;userName\&quot;: \&quot;梁越\&quot;       },      {         \&quot;certCode\&quot;: \&quot;412728199908212825\&quot;,         \&quot;email\&quot;: \&quot;t_dongjr@cnnp.com.cn\&quot;,         \&quot;phone\&quot;: \&quot;13137910705\&quot;,         \&quot;sex\&quot;: \&quot;2\&quot;,         \&quot;userCode\&quot;: \&quot;80292922\&quot;,         \&quot;userName\&quot;: \&quot;董静茹\&quot;       }    ],     &lt;span class&#x3D;\&quot;colour\&quot; style&#x3D;\&quot;color: rgb(163, 21, 21);\&quot;&gt;\&quot;powerInfoList\&quot;&lt;/span&gt;&lt;span class&#x3D;\&quot;colour\&quot; style&#x3D;\&quot;color: rgb(0, 0, 0);\&quot;&gt;: [&lt;/span&gt; { \&quot;id\&quot;: 1, \&quot;powerId\&quot;: \&quot;QS\&quot;, \&quot;powerName\&quot;: \&quot;秦山核电\&quot; }, { \&quot;id\&quot;: 2, \&quot;powerId\&quot;: \&quot;XP\&quot;, \&quot;powerName\&quot;: \&quot;霞浦核电\&quot; } ],     \&quot;staticCodeMappings\&quot;: {       \&quot;fact_category\&quot;: [         {           \&quot;id\&quot;: 456,           \&quot;isDefault\&quot;: 1,           \&quot;itemCode\&quot;: \&quot;PROGRAM_INSUFFICENT\&quot;,           \&quot;itemName\&quot;: \&quot;程序知道执行不足\&quot;,           \&quot;parentId\&quot;: 0,           \&quot;sort\&quot;: 1,           \&quot;typeId\&quot;: 127         },        {           \&quot;id\&quot;: 457,           \&quot;isDefault\&quot;: 1,           \&quot;itemCode\&quot;: \&quot;PROGRAM_QUALITY_PROBLEM\&quot;,           \&quot;itemName\&quot;: \&quot;程序制度质量问题\&quot;,           \&quot;parentId\&quot;: 0,           \&quot;sort\&quot;: 2,           \&quot;typeId\&quot;: 127         },        {           \&quot;id\&quot;: 458,           \&quot;isDefault\&quot;: 1,           \&quot;itemCode\&quot;: \&quot;PROGRAM_UN_CONSTRAINT\&quot;,           \&quot;itemName\&quot;: \&quot;程序制度未满足上游规范标准\&quot;,           \&quot;parentId\&quot;: 0,           \&quot;sort\&quot;: 3,           \&quot;typeId\&quot;: 127         },        {           \&quot;id\&quot;: 459,           \&quot;isDefault\&quot;: 1,           \&quot;itemCode\&quot;: \&quot;MANUAL_OPERATION_ERROR\&quot;,           \&quot;itemName\&quot;: \&quot;人员行为偏差\&quot;,           \&quot;parentId\&quot;: 0,           \&quot;sort\&quot;: 4,           \&quot;typeId\&quot;: 127         },        {           \&quot;id\&quot;: 460,           \&quot;isDefault\&quot;: 1,           \&quot;itemCode\&quot;: \&quot;DESIGN_DEFECTS\&quot;,           \&quot;itemName\&quot;: \&quot;设计缺陷\&quot;,           \&quot;parentId\&quot;: 0,           \&quot;sort\&quot;: 5,           \&quot;typeId\&quot;: 127         },        {           \&quot;id\&quot;: 461,           \&quot;isDefault\&quot;: 1,           \&quot;itemCode\&quot;: \&quot;UN_TIME_PROCESSED\&quot;,           \&quot;itemName\&quot;: \&quot;未及时消缺\&quot;,           \&quot;parentId\&quot;: 0,           \&quot;sort\&quot;: 6,           \&quot;typeId\&quot;: 127         }      ],       \&quot;inspect_method\&quot;: [         {           \&quot;id\&quot;: 452,           \&quot;isDefault\&quot;: 1,           \&quot;itemCode\&quot;: \&quot;STAFF_INTERVIEW\&quot;,           \&quot;itemName\&quot;: \&quot;人员访谈\&quot;,           \&quot;parentId\&quot;: 0,           \&quot;sort\&quot;: 1,           \&quot;typeId\&quot;: 126         },        {           \&quot;id\&quot;: 453,           \&quot;isDefault\&quot;: 1,           \&quot;itemCode\&quot;: \&quot;ACTIVITY_OBSERVATION\&quot;,           \&quot;itemName\&quot;: \&quot;活动观察\&quot;,           \&quot;parentId\&quot;: 0,           \&quot;sort\&quot;: 2,           \&quot;typeId\&quot;: 126         },        {           \&quot;id\&quot;: 454,           \&quot;isDefault\&quot;: 1,           \&quot;itemCode\&quot;: \&quot;SITE_INSPECTION\&quot;,           \&quot;itemName\&quot;: \&quot;现场巡视\&quot;,           \&quot;parentId\&quot;: 0,           \&quot;sort\&quot;: 3,           \&quot;typeId\&quot;: 126         },        {           \&quot;id\&quot;: 455,           \&quot;isDefault\&quot;: 1,           \&quot;itemCode\&quot;: \&quot;DOCUMENT_REVIEW\&quot;,           \&quot;itemName\&quot;: \&quot;文件查阅\&quot;,           \&quot;parentId\&quot;: 0,           \&quot;sort\&quot;: 4,           \&quot;typeId\&quot;: 126         }      ]     }   },   \&quot;responseStatus\&quot;: {     \&quot;ack\&quot;: \&quot;Success\&quot;,     \&quot;code\&quot;: \&quot;200\&quot;,     \&quot;timestamp\&quot;: 1755760426013   } } 2、查询筛选下拉框  {   \&quot;getFilterOptionVo\&quot;: {     \&quot;domainsMapping\&quot;: [       {         \&quot;key\&quot;: \&quot;HXGL\&quot;,         \&quot;keyValueList\&quot;: [           {             \&quot;key\&quot;: \&quot;SM\&quot;,             \&quot;value\&quot;: \&quot;2#电厂\&quot;           },          {             \&quot;key\&quot;: \&quot;QS\&quot;,             \&quot;value\&quot;: \&quot;1#电厂\&quot;           }        ],         \&quot;value\&quot;: \&quot;化学管理\&quot;       },      {         \&quot;key\&quot;: \&quot;HXGL1\&quot;,         \&quot;keyValueList\&quot;: [           {             \&quot;key\&quot;: \&quot;SM\&quot;,             \&quot;value\&quot;: \&quot;2#电厂\&quot;           },          {             \&quot;key\&quot;: \&quot;QS\&quot;,             \&quot;value\&quot;: \&quot;1#电厂\&quot;           }        ],         \&quot;value\&quot;: \&quot;化学管理1\&quot;       }    ],     \&quot;powerPlantKeyMapping\&quot;: [       {         \&quot;key\&quot;: \&quot;SM\&quot;,         \&quot;keyValueList\&quot;: [           {             \&quot;key\&quot;: \&quot;HXGL1\&quot;,             \&quot;value\&quot;: \&quot;化学管理1\&quot;           },          {             \&quot;key\&quot;: \&quot;HXGL\&quot;,             \&quot;value\&quot;: \&quot;化学管理\&quot;           }        ],         \&quot;value\&quot;: \&quot;2#电厂\&quot;       },      {         \&quot;key\&quot;: \&quot;QS\&quot;,         \&quot;keyValueList\&quot;: [           {             \&quot;key\&quot;: \&quot;HXGL1\&quot;,             \&quot;value\&quot;: \&quot;化学管理1\&quot;           },          {             \&quot;key\&quot;: \&quot;HXGL\&quot;,             \&quot;value\&quot;: \&quot;化学管理\&quot;           }        ],         \&quot;value\&quot;: \&quot;1#电厂\&quot;       }    ]   },   \&quot;responseStatus\&quot;: {     \&quot;ack\&quot;: \&quot;Success\&quot;,     \&quot;code\&quot;: \&quot;200\&quot;,     \&quot;timestamp\&quot;: 1755674260754   } } &#x60;&#x60;&#x60;

### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.models.*;
import org.openapitools.client.api.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    String contentType = "contentType_example"; // String | 
    PostApiGetBasicResourcesRequest postApiGetBasicResourcesRequest = new PostApiGetBasicResourcesRequest(); // PostApiGetBasicResourcesRequest | 
    try {
      Object result = apiInstance.apiGetBasicResourcesPost(contentType, postApiGetBasicResourcesRequest);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#apiGetBasicResourcesPost");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **contentType** | **String**|  | |
| **postApiGetBasicResourcesRequest** | [**PostApiGetBasicResourcesRequest**](PostApiGetBasicResourcesRequest.md)|  | [optional] |

### Return type

**Object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Successful response |  -  |

<a id="apiGetBasicUserInfoPost"></a>
# **apiGetBasicUserInfoPost**
> Object apiGetBasicUserInfoPost(contentType, body)

用户信息接口

请求样例： {}  返回样例：  &#x60;&#x60;&#x60; {   \&quot;data\&quot;: {     \&quot;userInfo\&quot;: {       \&quot;certCode\&quot;: \&quot;80301670\&quot;,       \&quot;email\&quot;: \&quot;t_tangyw03@cnnp.com.cn\&quot;,       \&quot;phone\&quot;: \&quot;17032840173\&quot;,       \&quot;sex\&quot;: \&quot;1\&quot;,       \&quot;userCode\&quot;: \&quot;80301670\&quot;,       \&quot;userName\&quot;: \&quot;唐亚伟\&quot;     }  },   \&quot;responseStatus\&quot;: {     \&quot;ack\&quot;: \&quot;Success\&quot;,     \&quot;code\&quot;: \&quot;200\&quot;,     \&quot;timestamp\&quot;: 1755755649298   }} &#x60;&#x60;&#x60;

### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.models.*;
import org.openapitools.client.api.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    String contentType = "contentType_example"; // String | 
    Object body = null; // Object | 
    try {
      Object result = apiInstance.apiGetBasicUserInfoPost(contentType, body);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#apiGetBasicUserInfoPost");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **contentType** | **String**|  | |
| **body** | **Object**|  | [optional] |

### Return type

**Object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Successful response |  -  |

<a id="apiGetCurrentTimestampPost"></a>
# **apiGetCurrentTimestampPost**
> Object apiGetCurrentTimestampPost(contentType, body)

获取当前的时间戳



### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.models.*;
import org.openapitools.client.api.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    String contentType = "contentType_example"; // String | 
    Object body = null; // Object | 
    try {
      Object result = apiInstance.apiGetCurrentTimestampPost(contentType, body);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#apiGetCurrentTimestampPost");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **contentType** | **String**|  | |
| **body** | **Object**|  | [optional] |

### Return type

**Object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Successful response |  -  |

<a id="apiGetInspectorsListPost"></a>
# **apiGetInspectorsListPost**
> Object apiGetInspectorsListPost(contentType, postApiGetInspectorsListRequest)

根据年份、电厂和领域获取专家列表



### Example
```java
// Import classes:
import org.openapitools.client.ApiClient;
import org.openapitools.client.ApiException;
import org.openapitools.client.Configuration;
import org.openapitools.client.models.*;
import org.openapitools.client.api.DefaultApi;

public class Example {
  public static void main(String[] args) {
    ApiClient defaultClient = Configuration.getDefaultApiClient();
    defaultClient.setBasePath("http://localhost");

    DefaultApi apiInstance = new DefaultApi(defaultClient);
    String contentType = "contentType_example"; // String | 
    PostApiGetInspectorsListRequest postApiGetInspectorsListRequest = new PostApiGetInspectorsListRequest(); // PostApiGetInspectorsListRequest | 
    try {
      Object result = apiInstance.apiGetInspectorsListPost(contentType, postApiGetInspectorsListRequest);
      System.out.println(result);
    } catch (ApiException e) {
      System.err.println("Exception when calling DefaultApi#apiGetInspectorsListPost");
      System.err.println("Status code: " + e.getCode());
      System.err.println("Reason: " + e.getResponseBody());
      System.err.println("Response headers: " + e.getResponseHeaders());
      e.printStackTrace();
    }
  }
}
```

### Parameters

| Name | Type | Description  | Notes |
|------------- | ------------- | ------------- | -------------|
| **contentType** | **String**|  | |
| **postApiGetInspectorsListRequest** | [**PostApiGetInspectorsListRequest**](PostApiGetInspectorsListRequest.md)|  | [optional] |

### Return type

**Object**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Successful response |  -  |

