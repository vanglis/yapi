

# PostApiGetInspectorsListRequest


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**year** | **String** |  |  |
|**powerId** | **String** |  |  [optional] |
|**domainCode** | **String** |  |  [optional] |



